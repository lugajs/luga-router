describe("luga.history", function(){

	"use strict";

	beforeEach(function(){

	});

	it("Lives inside its own namespace", function(){
		expect(luga.history).toBeDefined();
	});

});