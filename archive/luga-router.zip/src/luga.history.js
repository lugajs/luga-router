(function(){
	"use strict";

	luga.namespace("luga.history");

	luga.router.version = "0.1.0";


}());